##login_step.#!/usr/bin/env ruby -wKU

Dado("que eu esteja no formulario de login") do
  visit('http://the-internet.herokuapp.com/login')
end

Quando("eu preencher o usuario invalido") do
  fill_in('username', :with => 'tomsmith')
  sleep 5
end

Quando("preencher uma senha invalida") do
  fill_in('password', :with => 'SuperSecretPassword!')
  sleep 10
end

Quando("clicar para fazer login") do
  click_button('Login')
end

Entao("uma mensagem de erro no password sera exibida.") do
  pending # Write code here that turns the phrase above into concrete actions
end

Dado("que eu esteja no formulario de Login") do
  pending # Write code here that turns the phrase above into concrete actions
end

Quando("eu preencher os campos com dados validos") do
  pending # Write code here that turns the phrase above into concrete actions
end

Quando("clicar para fazer Login") do
  pending # Write code here that turns the phrase above into concrete actions
end

Entao("serei redirecionada para a pagina do Login.") do
  pending # Write code here that turns the phrase above into concrete actions
end
